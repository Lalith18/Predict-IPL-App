package com.predict_ipl

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
