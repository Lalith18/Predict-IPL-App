import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:predict_ipl/widgets/ReusableCard.dart';
import 'package:predict_ipl/widgets/Constants.dart';
import 'package:predict_ipl/widgets/MainDrawer.dart';

class HomeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.deepPurple,
      drawer: MainDrawer(),
      appBar: AppBar(
        iconTheme: IconThemeData(color: Colors.deepPurple),
        title: Text(
          'HOME',
          textAlign: TextAlign.center,
          style: TextStyle(
              color: Colors.deepPurple,
              fontSize: 25,
              fontWeight: FontWeight.bold),
        ),
        backgroundColor: Colors.white,
      ),
      body: Column(
        children: [
          Expanded(
              child: Row(
            children: [
              Expanded(
                  child: ReusableCard(
                cardChild: Center(
                  child: Text(
                    'PREDICT',
                    style: headingStyle,
                    textAlign: TextAlign.center,
                  ),
                ),
                onTap: () {
                  Navigator.pushNamed(context, 'PredictScreen');
                },
              )),
              Expanded(
                  child: ReusableCard(
                cardChild: Center(
                  child: Text(
                    'LEADER BOARD',
                    style: headingStyle,
                    textAlign: TextAlign.center,
                  ),
                ),
                onTap: () {
                  Navigator.pushNamed(context, 'LeaderBoardScreen');
                },
              )),
            ],
          )),
          Expanded(
              child: Row(
            children: [
              Expanded(
                  child: ReusableCard(
                cardChild: Center(
                  child: Text(
                    'GROUP CHAT',
                    style: headingStyle,
                    textAlign: TextAlign.center,
                  ),
                ),
                onTap: () {
                  Navigator.pushNamed(context, 'ChatScreen');
                },
              )),
              Expanded(
                  child: ReusableCard(
                cardChild: Center(
                  child: Text(
                    'PROFILE',
                    style: headingStyle,
                    textAlign: TextAlign.center,
                  ),
                ),
                onTap: () {
                  Navigator.pushNamed(context, 'ProfileScreen');
                },
              )),
            ],
          ))
        ],
      ),
    );
  }
}

//actions: <Widget>[
//DropdownButtonHideUnderline(
//child: DropdownButton(
//dropdownColor: Colors.white,
//onChanged: (itemIdentifier) {
//if (itemIdentifier == 'logout') {
//FirebaseAuth.instance.signOut();
//Navigator.pushNamed(context, 'SignUpLoginScreen');
//} else if (itemIdentifier == 'admin') {
//Navigator.pushNamed(context, 'AdminScreen');
//}
//},
//icon: Icon(
//Icons.more_vert,
//size: 40.0,
//color: Colors.deepPurple,
//),
//items: [
//DropdownMenuItem(
//value: 'logout',
//child: Container(
//child: Row(
//mainAxisAlignment: MainAxisAlignment.spaceBetween,
//children: <Widget>[
//Icon(
//Icons.exit_to_app,
//color: Colors.deepPurple,
//),
//Text(
//'LOGOUT',
//style: TextStyle(
//fontWeight: FontWeight.bold,
//fontSize: 20.0,
//color: Colors.deepPurple,
//),
//)
//],
//),
//),
//),
//DropdownMenuItem(
//value: 'admin',
//child: Container(
//child: Row(
//mainAxisAlignment: MainAxisAlignment.spaceBetween,
//children: <Widget>[
//Icon(
//Icons.account_box,
//color: Colors.deepPurple,
//),
//SizedBox(
//width: 10.0,
//),
//Text(
//'ADMIN ACCESS',
//style: TextStyle(
//fontWeight: FontWeight.bold,
//fontSize: 20.0,
//color: Colors.deepPurple,
//),
//)
//],
//),
//)),
//]),
//)
//],
