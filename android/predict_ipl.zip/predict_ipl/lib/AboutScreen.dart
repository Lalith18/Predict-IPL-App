import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:predict_ipl/widgets/Constants.dart';
import 'package:predict_ipl/widgets/ReusableCard.dart';

class AboutScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Text(
            'About',
            style: headingStyle,
          ),
          backgroundColor: Colors.white,
          iconTheme: IconThemeData(color: Colors.deepPurple),
        ),
        backgroundColor: Colors.deepPurple,
        body: SingleChildScrollView(
          child: Column(
            children: [
              ReusableCard(
                  onTap: () {},
                  cardChild: Padding(
                    padding: EdgeInsets.all(20),
                    child: Container(
                      width: double.infinity,
                      child: Column(
                        children: [
                          Text(
                            'DEVELOPER',
                            style: headingStyle,
                          ),
                          SizedBox(
                            height: 20,
                          ),
                          ClipRRect(
                            child: Image.asset(
                              'images/lalith1.jpg',
                              height: 100,
                            ),
                            borderRadius: BorderRadius.circular(20),
                          ),
                          Text(
                            'LALITH K',
                            style: headingStyle,
                          ),
                          Text(
                            'For projects or collaborations contact:',
                            style: TextStyle(color: Colors.black, fontSize: 20),
                          ),
                          Text(
                            'Email: leftoverdeveloper1@gmail.com \nPhone: 9150754624',
                            style: TextStyle(fontSize: 17),
                          ),
                        ],
                      ),
                    ),
                  )),
              ReusableCard(
                  onTap: () {},
                  cardChild: Padding(
                      padding: EdgeInsets.all(10),
                      child: Container(
                        width: double.infinity,
                        child: Column(
                          children: [
                            Text(
                              'ADMIN',
                              style: headingStyle,
                            ),
                            Row(
                              children: [
                                ClipRRect(
                                  child: Image.asset(
                                    'images/ramasamy.jpg',
                                    height: 100,
                                  ),
                                  borderRadius: BorderRadius.circular(10),
                                ),
                                SizedBox(
                                  width: 20,
                                ),
                                Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      'RAMASAMY',
                                      style: TextStyle(
                                          color: Colors.deepPurple,
                                          fontSize: 22,
                                          fontWeight: FontWeight.w600),
                                    ),
                                    Text(
                                      'System analyst \nData scientist',
                                      style: TextStyle(
                                          color: Colors.deepPurple,
                                          fontSize: 20),
                                      textAlign: TextAlign.left,
                                    ),
                                  ],
                                )
                              ],
                            ),
                            SizedBox(
                              height: 15,
                            ),
                            Row(
                              children: [
                                ClipRRect(
                                  child: Image.asset(
                                    'images/harish.jpg',
                                    height: 100,
                                  ),
                                  borderRadius: BorderRadius.circular(10),
                                ),
                                SizedBox(
                                  width: 20,
                                ),
                                Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      'HARISH SHANKAR',
                                      style: TextStyle(
                                          color: Colors.deepPurple,
                                          fontSize: 22,
                                          fontWeight: FontWeight.w600),
                                    ),
                                    Text(
                                      'App strategist \nUX specialist',
                                      style: TextStyle(
                                          color: Colors.deepPurple,
                                          fontSize: 20),
                                      textAlign: TextAlign.left,
                                    ),
                                  ],
                                )
                              ],
                            ),
                          ],
                        ),
                      ))),
              ReusableCard(
                onTap: () {},
                cardChild: Padding(
                  padding: EdgeInsets.all(10),
                  child: Container(
                    width: double.infinity,
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(
                          'ABOUT APP',
                          style: headingStyle,
                        ),
                        SizedBox(
                          height: 10,
                        ),
                        Text(
                            'VERSION:                           1.2.5 \nSDK :                                   FLUTTER \nDATABASE:                        FIREBASE \nINITIAL RELEASE DATE:  17 SEPTEMBER 2020 \nDEVELOPMENT PERIOD: 2 MONTHS')
                      ],
                    ),
                  ),
                ),
              )
            ],
          ),
        ));
  }
}
