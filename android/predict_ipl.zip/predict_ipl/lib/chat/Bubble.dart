import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class Bubble extends StatelessWidget {
  Bubble(this.username, this.message, this.isMe, this.isAdmin, this.key,
      this.documentId);
  final String message, username;
  final bool isMe;
  final bool isAdmin;
  final Key key;
  final String documentId;

  void removeChat(String documentId) async {
    await FirebaseFirestore.instance
        .collection('chats')
        .doc(documentId)
        .delete();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onDoubleTap: isAdmin
          ? () {
              removeChat(documentId);
            }
          : () {},
      child: Row(
        mainAxisAlignment:
            isMe ? MainAxisAlignment.end : MainAxisAlignment.start,
        children: <Widget>[
          Flexible(
            child: Container(
              decoration: BoxDecoration(
                color: isMe ? Colors.deepPurple : Colors.pinkAccent,
                borderRadius: isMe
                    ? BorderRadius.only(
                        topLeft: Radius.circular(15.0),
                        bottomRight: Radius.circular(15.0),
                        bottomLeft: Radius.circular(15.0),
                      )
                    : BorderRadius.only(
                        topRight: Radius.circular(15.0),
                        bottomRight: Radius.circular(15.0),
                        bottomLeft: Radius.circular(15.0)),
              ),
              padding: EdgeInsets.symmetric(vertical: 4, horizontal: 8),
              margin: EdgeInsets.symmetric(vertical: 4, horizontal: 8),
              child: Column(
                crossAxisAlignment:
                    isMe ? CrossAxisAlignment.end : CrossAxisAlignment.start,
                children: <Widget>[
                  Text(
                    username,
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                      fontSize: 22,
                    ),
                  ),
                  Text(
                    message,
                    style: TextStyle(color: Colors.white, fontSize: 20),
                    textAlign: isMe ? TextAlign.end : TextAlign.start,
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
