import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:predict_ipl/widgets/ReusableCard.dart';
import 'package:predict_ipl/widgets/Constants.dart';
import 'package:predict_ipl/team/TeamData.dart';
import 'package:predict_ipl/team/TeamClass.dart';
import 'package:predict_ipl/widgets/PinkButton.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class PredictScreen extends StatefulWidget {
  @override
  _PredictScreenState createState() => _PredictScreenState();
}

enum TeamSelect {
  team1,
  team2,
}

enum TossSelect {
  bat,
  bowl,
}

class _PredictScreenState extends State<PredictScreen> {
  String teamChosen = 'team1', tossChosen = 'bat';
  var teamSelect = TeamSelect.team1;
  var tossSelect = TossSelect.bat;
  Team team1 = Teams[8];
  Team team2 = Teams[8];
  int matchNumber = 0;
  int runs = 150;
  int wickets = 4;
  bool _canPredict = false;
  User loggedInUser;
  DocumentSnapshot documents;
  var pointDoc;
  String username;

  final SnackBar snackBar = SnackBar(
    content: Text(
      'Time Up! You cannot predict.',
      style: TextStyle(fontSize: 20),
    ),
    duration: Duration(seconds: 2),
  );

  Future<void> getDocuments(String userEmail) async {
    final pointsData = await FirebaseFirestore.instance
        .collection('points')
        .doc(userEmail)
        .get();
    documents = pointsData;
  }

  void getCurrentUser() async {
    try {
      final user = FirebaseAuth.instance.currentUser;
      if (user != null) {
        loggedInUser = user;
        final userDoc = await FirebaseFirestore.instance
            .collection('users')
            .doc(loggedInUser.uid)
            .get();
        username = userDoc.get('username');
        final QuerySnapshot result = await FirebaseFirestore.instance
            .collection('points')
            .where('email', isEqualTo: loggedInUser.email)
            .get();
        pointDoc = result.docs;
      }
    } catch (e) {
      print(e);
    }
  }

  void getMatch() async {
    final matchData = await FirebaseFirestore.instance
        .collection('new match')
        .doc('xNShtGFMSjCD0Nbg5avM')
        .get();
    setState(() {
      team1 = Teams[matchData.get('team1')];
      team2 = Teams[matchData.get('team2')];
      matchNumber = matchData.get('matchNumber');
      _canPredict = matchData.get('can predict');
    });
  }

  @override
  void initState() {
    super.initState();
    getMatch();
    getCurrentUser();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        title: Text(
          'PREDICT',
          style: headingStyle,
        ),
        iconTheme: IconThemeData(color: Colors.deepPurple),
        actions: [
          IconButton(
              icon: Icon(
                Icons.announcement,
                size: 30,
              ),
              onPressed: () {})
        ],
      ),
      backgroundColor: Colors.deepPurple,
      body: Builder(
        builder: (ctx) => SingleChildScrollView(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              SizedBox(
                height: 10,
              ),
              Text(
                'WINNING TEAM',
                style: headingStyleWhite,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  ReusableCard(
                    cardChild: Container(
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(10.0),
                          border: teamSelect == TeamSelect.team1
                              ? Border.all(color: Colors.pinkAccent, width: 4)
                              : null),
                      height: 100,
                      width: 150,
                      child: Center(child: Image.asset(team1.imageAddress)),
                    ),
                    onTap: () {
                      setState(() {
                        teamSelect = TeamSelect.team1;
                        teamChosen = 'team1';
                      });
                    },
                  ),
                  ReusableCard(
                    cardChild: Container(
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(10.0),
                          border: teamSelect == TeamSelect.team2
                              ? Border.all(color: Colors.pinkAccent, width: 4)
                              : null),
                      height: 100,
                      width: 150,
                      child: Center(child: Image.asset(team2.imageAddress)),
                    ),
                    onTap: () {
                      setState(() {
                        teamSelect = TeamSelect.team2;
                        teamChosen = 'team2';
                      });
                    },
                  )
                ],
              ),
              Text(
                'TOSS WINNER WILL CHOOSE',
                style: headingStyleWhite,
                textAlign: TextAlign.center,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  ReusableCard(
                    cardChild: Container(
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(10.0),
                          border: tossSelect == TossSelect.bat
                              ? Border.all(color: Colors.pinkAccent, width: 4)
                              : null),
                      height: 100,
                      width: 150,
                      child: Center(
                        child: Text(
                          'BAT',
                          style: headingStyle,
                          textAlign: TextAlign.center,
                        ),
                      ),
                    ),
                    onTap: () {
                      setState(() {
                        tossSelect = TossSelect.bat;
                        tossChosen = 'bat';
                      });
                    },
                  ),
                  ReusableCard(
                    cardChild: Container(
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(10.0),
                          border: tossSelect == TossSelect.bowl
                              ? Border.all(color: Colors.pinkAccent, width: 4)
                              : null),
                      height: 100,
                      width: 150,
                      child: Center(
                        child: Text(
                          'BOWL',
                          style: headingStyle,
                          textAlign: TextAlign.center,
                        ),
                      ),
                    ),
                    onTap: () {
                      setState(() {
                        tossSelect = TossSelect.bowl;
                        tossChosen = 'bowl';
                      });
                    },
                  ),
                ],
              ),
              ReusableCard(
                cardChild: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    SizedBox(
                      height: 10,
                    ),
                    Text(
                      'SCORE',
                      style: headingStyle,
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.baseline,
                      textBaseline: TextBaseline.alphabetic,
                      children: [
                        Text(
                          runs.toString(),
                          style: headingStyle,
                        ),
                        Text(
                          'runs',
                          style:
                              TextStyle(fontSize: 20, color: Colors.deepPurple),
                        )
                      ],
                    ),
                    Slider(
                        value: runs.toDouble(),
                        activeColor: Colors.pink,
                        inactiveColor: Colors.grey,
                        min: 20,
                        max: 270,
                        onChanged: (value) {
                          setState(() {
                            runs = value.round();
                          });
                        })
                  ],
                ),
                onTap: () {},
              ),
              ReusableCard(
                cardChild: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    SizedBox(
                      height: 10,
                    ),
                    Text(
                      'WICKETS',
                      style: headingStyle,
                      textAlign: TextAlign.center,
                    ),
                    Text(
                      wickets.toString(),
                      style: headingStyle,
                    ),
                    Slider(
                        value: wickets.toDouble(),
                        activeColor: Colors.pink,
                        inactiveColor: Colors.grey,
                        min: 0,
                        max: 10,
                        onChanged: (value) {
                          setState(() {
                            wickets = value.round();
                          });
                        })
                  ],
                ),
                onTap: () {},
              ),
              PinkButton(
                  title: 'PREDICT',
                  onTap: _canPredict
                      ? () {
                          Scaffold.of(ctx).showSnackBar(SnackBar(
                              content:
                                  Text('Your Prediction has been saved.')));
                          if (pointDoc.length < 1) {
                            FirebaseFirestore.instance
                                .collection('points')
                                .doc(loggedInUser.email)
                                .set({
                              'points': 0.1,
                              'email': loggedInUser.email,
                              'username': username,
                            });
                          }
                          FirebaseFirestore.instance
                              .collection('predictions')
                              .doc(loggedInUser.email)
                              .set({
                            'matchNumber': matchNumber,
                            'team': teamChosen,
                            'toss': tossChosen,
                            'score': runs,
                            'wickets': wickets,
                            'email': loggedInUser.email
                          });
                        }
                      : () {
                          Scaffold.of(ctx).showSnackBar(snackBar);
                        })
            ],
          ),
        ),
      ),
    );
  }
}
