import 'package:predict_ipl/team/TeamClass.dart';

const Teams = [
  Team(name: 'CSK', imageAddress: 'images/csk.png'),
  Team(name: 'MI', imageAddress: 'images/mi.png'),
  Team(name: 'RCB', imageAddress: 'images/rcb.png'),
  Team(name: 'SRH', imageAddress: 'images/srh.png'),
  Team(name: 'RR', imageAddress: 'images/rr.png'),
  Team(name: 'KXIP', imageAddress: 'images/kxip.png'),
  Team(name: 'KKR', imageAddress: 'images/kkr.png'),
  Team(name: 'DC', imageAddress: 'images/dc.png'),
  Team(name: 'BLANK', imageAddress: 'images/blank.jpg'),
];
