import 'package:flutter/material.dart';

class Team {
  const Team({@required this.name, @required this.imageAddress});
  final name, imageAddress;
}
