import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:predict_ipl/widgets/ReusableCard.dart';
import 'package:predict_ipl/widgets/Constants.dart';
import 'package:predict_ipl/team/TeamData.dart';
import 'package:predict_ipl/team/TeamClass.dart';
import 'package:predict_ipl/widgets/PinkButton.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:modal_progress_hud/modal_progress_hud.dart';

class AnsScreen extends StatefulWidget {
  @override
  _AnsScreenState createState() => _AnsScreenState();
}

enum TeamSelect {
  team1,
  team2,
}

enum TossSelect {
  bat,
  bowl,
}

class _AnsScreenState extends State<AnsScreen> {
  String predictedTeam, predictedToss, userEmail;
  int predictedScore, predictedWickets, predictedMatchNumber;
  String crctTeam = 'team1', crctToss = 'bat';
  var teamSelect = TeamSelect.team1;
  var tossSelect = TossSelect.bat;
  Team team1 = Teams[8];
  Team team2 = Teams[8];
  int crctRuns = 150;
  int crctWickets = 4;
  int matchNumber = 0;
  String username;
  DocumentSnapshot documents;
  bool _isLoading = false;

  getUserPoints() async {
    try {
      final pointsData =
          await FirebaseFirestore.instance.collection('points').get();
      return pointsData;
    } catch (e) {
      print(e);
    }
  }

  int modulus(int num) {
    if (num >= 0) {
      return num;
    }
    return -num;
  }

  getUserPrediction() async {
    try {
      final predictionData =
          await FirebaseFirestore.instance.collection('predictions').get();
      return predictionData;
    } catch (e) {
      print(e);
    }
  }

  void getMatch() async {
    final matchData = await FirebaseFirestore.instance
        .collection('new match')
        .doc('xNShtGFMSjCD0Nbg5avM')
        .get();
    setState(() {
      team1 = Teams[matchData.get('team1')];
      team2 = Teams[matchData.get('team2')];
      matchNumber = matchData.get('matchNumber');
    });
  }

  @override
  void initState() {
    super.initState();
    getMatch();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        title: Text(
          'UPDATE ANSWERS',
          style: headingStyle,
        ),
        iconTheme: IconThemeData(color: Colors.deepPurple),
      ),
      backgroundColor: Colors.deepPurple,
      body: ModalProgressHUD(
        inAsyncCall: _isLoading,
        child: Builder(
          builder: (ctx) => SingleChildScrollView(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                SizedBox(
                  height: 10,
                ),
                Text(
                  'WINNING TEAM',
                  style: headingStyleWhite,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    ReusableCard(
                      cardChild: Container(
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(10.0),
                            border: teamSelect == TeamSelect.team1
                                ? Border.all(color: Colors.pinkAccent, width: 4)
                                : null),
                        height: 100,
                        width: 150,
                        child: Center(child: Image.asset(team1.imageAddress)),
                      ),
                      onTap: () {
                        setState(() {
                          teamSelect = TeamSelect.team1;
                          crctTeam = 'team1';
                        });
                      },
                    ),
                    ReusableCard(
                      cardChild: Container(
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(10.0),
                            border: teamSelect == TeamSelect.team2
                                ? Border.all(color: Colors.pinkAccent, width: 4)
                                : null),
                        height: 100,
                        width: 150,
                        child: Center(child: Image.asset(team2.imageAddress)),
                      ),
                      onTap: () {
                        setState(() {
                          teamSelect = TeamSelect.team2;
                          crctTeam = 'team2';
                        });
                      },
                    )
                  ],
                ),
                Text(
                  'TOSS WINNER CHOSE',
                  style: headingStyleWhite,
                  textAlign: TextAlign.center,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    ReusableCard(
                      cardChild: Container(
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(10.0),
                            border: tossSelect == TossSelect.bat
                                ? Border.all(color: Colors.pinkAccent, width: 4)
                                : null),
                        height: 100,
                        width: 150,
                        child: Center(
                          child: Text(
                            'BAT',
                            style: headingStyle,
                            textAlign: TextAlign.center,
                          ),
                        ),
                      ),
                      onTap: () {
                        setState(() {
                          tossSelect = TossSelect.bat;
                          crctToss = 'bat';
                        });
                      },
                    ),
                    ReusableCard(
                      cardChild: Container(
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(10.0),
                            border: tossSelect == TossSelect.bowl
                                ? Border.all(color: Colors.pinkAccent, width: 4)
                                : null),
                        height: 100,
                        width: 150,
                        child: Center(
                          child: Text(
                            'BOWL',
                            style: headingStyle,
                            textAlign: TextAlign.center,
                          ),
                        ),
                      ),
                      onTap: () {
                        setState(() {
                          tossSelect = TossSelect.bowl;
                          crctToss = 'bowl';
                        });
                      },
                    ),
                  ],
                ),
                ReusableCard(
                  cardChild: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      SizedBox(
                        height: 10,
                      ),
                      Text(
                        'SCORE',
                        style: headingStyle,
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.baseline,
                        textBaseline: TextBaseline.alphabetic,
                        children: [
                          Text(
                            crctRuns.toString(),
                            style: headingStyle,
                          ),
                          Text(
                            'runs',
                            style: TextStyle(
                                fontSize: 20, color: Colors.deepPurple),
                          )
                        ],
                      ),
                      Slider(
                          value: crctRuns.toDouble(),
                          activeColor: Colors.pink,
                          inactiveColor: Colors.grey,
                          min: 20,
                          max: 270,
                          onChanged: (value) {
                            setState(() {
                              crctRuns = value.round();
                            });
                          })
                    ],
                  ),
                  onTap: () {},
                ),
                ReusableCard(
                  cardChild: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      SizedBox(
                        height: 10,
                      ),
                      Text(
                        'WICKETS',
                        style: headingStyle,
                        textAlign: TextAlign.center,
                      ),
                      Text(
                        crctWickets.toString(),
                        style: headingStyle,
                      ),
                      Slider(
                          value: crctWickets.toDouble(),
                          activeColor: Colors.pink,
                          inactiveColor: Colors.grey,
                          min: 0,
                          max: 10,
                          onChanged: (value) {
                            setState(() {
                              crctWickets = value.round();
                            });
                          })
                    ],
                  ),
                  onTap: () {},
                ),
                FutureBuilder(
                    future: getUserPrediction(),
                    builder: (context, snapshot) {
                      if (!snapshot.hasData) {
                        return CircularProgressIndicator();
                      }
                      return FutureBuilder(
                          future: getUserPoints(),
                          builder: (context, pointsSnapshot) {
                            if (!pointsSnapshot.hasData) {
                              return CircularProgressIndicator();
                            }
                            return PinkButton(
                                title: 'UPDATE ANSWER',
                                onTap: () {
                                  setState(() {
                                    _isLoading = true;
                                  });
                                  Scaffold.of(ctx).showSnackBar(SnackBar(
                                      content: Text(
                                          'Correct answers has been saved.')));
                                  FirebaseFirestore.instance
                                      .collection('correct answer')
                                      .doc('IuIigQfMmSvcsmhXtXGC')
                                      .set({
                                    'matchNumber': matchNumber,
                                    'team': crctTeam,
                                    'toss': crctToss,
                                    'score': crctRuns,
                                    'wickets': crctWickets,
                                  });
                                  final userPredict = snapshot.data.documents;
                                  final pointsData =
                                      pointsSnapshot.data.documents;
                                  for (dynamic document in userPredict) {
                                    predictedTeam = document.get('team');
                                    predictedToss = document.get('toss');
                                    predictedScore = document.get('score');
                                    predictedWickets = document.get('wickets');
                                    predictedMatchNumber =
                                        document.get('matchNumber');
                                    userEmail = document.get('email');
                                    if (predictedMatchNumber == matchNumber) {
                                      double points;
                                      for (dynamic doc in pointsData) {
                                        if (doc.get('email') == userEmail) {
                                          points = doc.get('points');
                                          username = doc.get('username');
                                          points += ((270 -
                                                      modulus(crctRuns -
                                                          predictedScore)) /
                                                  270) *
                                              50;
                                          points += ((10 -
                                                      modulus(crctWickets -
                                                          predictedWickets)) /
                                                  10) *
                                              50;
                                          if (predictedTeam == crctTeam) {
                                            points += 50;
                                          }
                                          if (predictedToss == crctToss) {
                                            points += 25;
                                          }
                                          print(points);
                                          FirebaseFirestore.instance
                                              .collection('points')
                                              .doc(userEmail)
                                              .set({
                                            'points': points,
                                            'email': userEmail,
                                            'username': username,
                                          });
                                        }
                                      }
                                    }
                                  }
                                  setState(() {
                                    _isLoading = false;
                                  });
                                });
                          });
                    })
              ],
            ),
          ),
        ),
      ),
    );
  }
}
