import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:predict_ipl/widgets/Constants.dart';

class LeaderBoardTile extends StatelessWidget {
  LeaderBoardTile(this.name, this.points, this.position);
  final int position;
  final double points;
  final String name;
  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
          color: Colors.white,
          border: Border.all(color: Colors.deepPurple, width: 2)),
      margin: EdgeInsets.symmetric(horizontal: 10),
      height: 70,
      width: double.infinity,
      child: Container(
        decoration: BoxDecoration(
            border: Border.all(color: Colors.pinkAccent, width: 5)),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Container(
              width: 70,
              decoration: BoxDecoration(
                  border: Border.all(color: Colors.pinkAccent, width: 5),
                  color: Colors.deepPurple),
              child: Center(
                child: Text(
                  (position + 1).toString(),
                  style: headingStyleWhite,
                ),
              ),
            ),
            Text(
              name,
              style: TextStyle(
                  color: Colors.deepPurple,
                  fontSize: 30,
                  fontWeight: FontWeight.bold),
            ),
            Container(
              decoration: BoxDecoration(
                border: Border.all(color: Colors.pinkAccent, width: 5),
                color: Colors.deepPurple,
              ),
              child: Text(
                (points - 0.1).round().toString(),
                style: headingStyleWhite,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
