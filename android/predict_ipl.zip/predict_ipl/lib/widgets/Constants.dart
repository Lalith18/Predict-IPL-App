import 'package:flutter/material.dart';

final headingStyle = TextStyle(
    color: Colors.deepPurple, fontSize: 30, fontWeight: FontWeight.bold);

final subHeadingStyle = TextStyle(
    color: Colors.deepPurple, fontSize: 20, fontWeight: FontWeight.bold);

final headingStyleWhite =
    TextStyle(color: Colors.white, fontSize: 30, fontWeight: FontWeight.bold);
