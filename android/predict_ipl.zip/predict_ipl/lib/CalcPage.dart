import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:predict_ipl/widgets/Constants.dart';

class CalcPage extends StatefulWidget {
  @override
  _CalcPageState createState() => _CalcPageState();
}

class _CalcPageState extends State<CalcPage> {
  User loggedInUser;
  String teamWon, tossChosen, predictedTeam, predictedToss;
  int crctScore, crctWickets, predictedScore, predictedWickets;

  void getCurrentUser() async {
    try {
      final user = FirebaseAuth.instance.currentUser;
      if (user != null) {
        loggedInUser = user;
        final predictionData = await FirebaseFirestore.instance
            .collection('predictions')
            .doc(loggedInUser.email)
            .get();
        predictedTeam = predictionData.get('team');
        predictedToss = predictionData.get('toss');
        predictedScore = predictionData.get('score');
        predictedWickets = predictionData.get('wickets');
      }
    } catch (e) {
      print(e);
    }
  }

  void getCrctAns() async {
    final crctMatchData = await FirebaseFirestore.instance
        .collection('correct ans')
        .doc('IuIigQfMmSvcsmhXtXGC')
        .get();
    teamWon = crctMatchData.get('team');
    tossChosen = crctMatchData.get('toss');
    crctScore = crctMatchData.get('score');
    crctWickets = crctMatchData.get('wickets');
  }

  @override
  void initState() {
    super.initState();
    getCurrentUser();
    getCrctAns();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        title: Text(
          'RESULTS',
          style: headingStyle,
        ),
        iconTheme: IconThemeData(color: Colors.deepPurple),
      ),
      body: SingleChildScrollView(
        child: Row(
          children: [
            Column(
              children: [],
            )
          ],
        ),
      ),
    );
  }
}
